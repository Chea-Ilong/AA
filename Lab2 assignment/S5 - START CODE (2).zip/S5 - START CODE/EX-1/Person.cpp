#include <iostream>
#include <string>
using namespace std;

class Person {
	// Write you code here
};


int main() {
    Person ronan("ronan", "ogor", 4785);

    ronan.setFirstName("ronano");
    std::cout << ronan.toString() << std::endl;

    return 0;
}