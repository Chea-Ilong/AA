#include <stdio.h>

int main()
{
    // TODO

    //  Enter the first person date of birth (year/month/day)
    //  Enter the second person date of birth (year/month/day)
    
    //  Depending on the 2 dates of birth, print either:
    //  - The first person is the youngest
    //  - The second person is the youngest
    //  - Both persons have the same age

    return 0;
}
