#include <stdio.h>

int main()
{
    // TODO
    //  Input the number, the range min and the range max 
    //  Output "inside" if the number is in the range [min, max], "outside" otherwise
 

    return 0;
}
