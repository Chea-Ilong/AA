#include <iostream>
using namespace std;

/**
 * Return whether the given number if inside the given range
 * @param number : the number
 * @param min : the range min
 * @param max : the range max
 * @return true if inside the range, false otherwise
 */
bool isInside(int number, int min, int max) {
    // TODO
    return true
}

int main() {
 
    // 1-  Input the number
   // TODO

    // 2 - Input the range

    // BONUS : If the user accidentally enters a minimum value that is larger
    // than the maximum value, ask them to enter the values again.
   
    // TODO

    // 3-  Check if the number is inside the range
   // TODO

    return 0;
}